# Keep app classes
-keep class com.touchlock.edge.** { *; }

# Strip all android.util.Log calls so zero runtime logs are emitted
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
    public static int wtf(...);
}
